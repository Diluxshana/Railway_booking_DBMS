<html>
<head>
	<title> HOME PAGE </title>
	<link rel="stylesheet" href="Style.css"/>
	
</head>

<body>

	<h1 class ="heading_style"> TICKET BOOKING SYSYTEM</h1>
	<br>
	<!--HOME PAGE-->
	<div class="home text-center">
		<div class="wrapper">
			<ul>
				<li><a href="Train_details.php">View train details</a></li>
				<li><a href="Seat availabilty.php">Seat availability</a></li>
				<li><a  href="Booking tickets.php">Booking tickets </a></li>
				<li><a href="view_booking_detail.php">Booking Details</a></li>
				<li><a href="Cancelling tickets.php">Cancelling tickets</a></li>
				
			</ul>
		</div>
	</div>

	<section>
	<h2 class="About_style"> ABOUT</h2>
	<br>
	<p> In railway stations station manager usually manages details of train and passengers, and also they have to provide the tickets by manually. For this purpose, here I’m proposing this railway ticket booking management system software</p><br>
	<p> Station managers are struggled to maintain the passengers details, train details and booking and cancelling tickets due to difficulty of manual system because rate of passengers are increased after fuel rate increase. In this modern world, all students are busy with their own works, so this booking system will help them to save their time, because of their work load if they won’t to cancel the ticket they will not cancel, for these purposes I am trying to optimize these problems by using this railway ticket booking management software.</p><br>
	<p> So, this ia website to create a database schema design based on the above requirements. It will include ticket booking system and database to maintain train details booked passengers details
Kilinochchi premises of UOJ students can book and cancel the tickets. My database will store each of the passenger id number, name, address, age, gender and mobile number. And also database can store the train no, train name train’s departure station and time, train’s arrival station and time. I have added railway station details which are available in northern province.
So every passenger can show the availability of train and seats and book the tickets and also they can easily cancel them if they don’t want.</p>

</section>
<br>
<section>
	<h3 class="Contact_style"> CONTACT US </h3>
	<br>
<div class="Contact">
	<ul>
		<li><img src="f1.png" style="width:25;height:25;"><a href="facebook.com">Facebook.com/OnlineBook</a></li>
		<li><img src="w1.png" style="width:25;height:25;"><a href="whatsapp.com">077563618</a></li>
		<li><img src="t1.png" style="width:25;height:25 ;"><a href="twitter.com">@IMQFT</a></li>
		<li><img src="i1.jpg" style="width:25;height:25;"><a href="instagram.com">Alisammeredith</a></li>
	</ul>
</div>
/*
<div class="Contact">
	<ul>
		<li><img src="a4.jpg" style="width:400px;height:600px;margin-top: 100px;"></li>
		<li><img src="d1.jpg" style="width:400px;height:600px;margin-top: 100px;"></li>
		<li><img src="a2.jpg" style="width:400px;height:600px;margin-top: 100px;"></li>
		
    </ul>
</div>
*/

<!--HOME PAGE END-->
</body>
</html>